--------------------

 [ About ]

    Nightly
    Night vision for Minecraft.

    By: Moxwel >> https://www.planetminecraft.com/member/moxwel/

    Tested on Minecraft:
    - 1.8
    - 1.14
    - 1.15
    - 1.17

    (It should work in any version)

--------------------

 [ Recommendations ]

    Requires OptiFine! >> https://optifine.net

--------------------

 [ Notes ]

    Minecraft 1.8 uses the "mcpatcher" folder, with OptiFine it should work in any version of Minecraft.

--------------------